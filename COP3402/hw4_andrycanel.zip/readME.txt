Make sure all the input files and lex.c are in the same folder
Then type "gcc parsercodegen.c -o parser" into the console
Then type "./parser <input file name>"
